bashobfus
=========

A small bash minifier/obfuscator written in Perl.
