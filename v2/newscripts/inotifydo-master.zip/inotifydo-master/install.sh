#!/usr/bin/env sh
cd "`dirname "$0"`"
ln -s "`pwd`/inotifydo" "/usr/bin/inotifydo"
